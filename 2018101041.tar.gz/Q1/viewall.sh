#!/usr/bin/env bash

column -s, -t < music.csv
