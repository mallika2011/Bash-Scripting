#!/usr/bin/env bash

if [[ $# -ne 1 ]]; then
echo "Error Please enter an argument"

else

awk -F "\"*,\"*" -v body="$1" '{ if($2==body) {print}}' rem.txt | sort -k4 -t',' -n | column -s, -t
fi
