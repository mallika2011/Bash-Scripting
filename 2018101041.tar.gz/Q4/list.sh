#!/usr/bin/env bash

sort -k4 -t',' -n rem.txt | column -s, -t 
