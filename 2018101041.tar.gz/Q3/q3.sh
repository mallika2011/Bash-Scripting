#!/usr/bin/env bash


#echo $1

if [[ $# -ne 1 ]];
then echo "Error"

else
    for ((i=1; $i<=$1; i++))
    do


       echo  "$i Work"
       sleep 1500

       if (($i%5==0)); then
       echo  "$i Break"
       sleep 300
     else
        echo "$i Break"
        sleep 900
      fi


    done
    #sleep 30
    #echo ""
echo Finished
fi
