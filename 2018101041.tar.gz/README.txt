
NAME : MALLIKA SUBRAMANIAN
ROLL : 2018101041

This file is a guideline to executing and using the scripts for Assignment 1

QUESTION 1:

-> Uses a single menu file, through which any particular script can be called.
-> IDs for each song (record) are inputted by the user.
-> "Song name", "ID", and "Artist" are mandatory fields.
-> Submission made includes all the scripts as well as a music.csv file for demo.
-> The script is case sensitive.


QUESTION 2:
-> It is case sensitive.
-> Order of command line arguments -
        Word
        URL
-> URL verification is done. 


QUESTION 3:
-> On running the script, the number of intervals of work and time is taken as a command line argument.

QUESTION 4:
-> Format to add a reminder <TIME> <BODY>
-> Time specified must be in 24Hr format.
-> Argument based listing requires one argument (body)
-> One menu script from which all scripts can be executed
-> Reminder IDs are uniquely assigned.
-> The script is case sensitive.
-> Includes a rem.txt for demo


QUESTION 5:
-> Supporting files for part a will be touched.
-> All other files (csv, txt) are attached.

QUESTION 6:
-> Commmand line arguments are -
        Path to the movie input file
        Destination Path
